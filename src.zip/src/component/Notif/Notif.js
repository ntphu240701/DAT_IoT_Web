import React from "react";

export default function Notif() {
  return <div className="DAT_Notif">Notifasdsadsa</div>;
}
