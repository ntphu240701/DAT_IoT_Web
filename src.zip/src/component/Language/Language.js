import React from 'react';
import './Language.scss';

function Language(props) {
    return (
        <div>
            
        </div>
    );
}

export default Language;