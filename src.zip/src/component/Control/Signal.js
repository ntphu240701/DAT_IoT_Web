import { signal } from "@preact/signals-react";

export const plantState = signal("default");
export const plantData = signal([]);
export const listDevice = signal([]);
export const mode = signal('overview');



