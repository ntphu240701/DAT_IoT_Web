export const action = (type,payload) =>{
        return{
                type: type,
                payload
        }
}
